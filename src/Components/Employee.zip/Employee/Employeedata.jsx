// import { IoSearch } from "react-icons/io5";
// import React, { useState } from 'react';
// import * as XLSX from 'xlsx';
// import axios from 'axios';
// import './employee.css';

// const ExcelUpload = () => {
//     const [data, setData] = useState([]);
//     const [filteredData, setFilteredData] = useState([]);
//     const [fileName, setFileName] = useState("");
//     const [searchTerm, setSearchTerm] = useState('');
//     const handleFileUpload = (event) => {
//         const file = event.target.files[0];
//         setFileName(file.name);
//         const reader = new FileReader();

//         reader.onload = (e) => {
//             const binaryStr = e.target.result;
//             const workbook = XLSX.read(binaryStr, { type: 'binary' });
//             const firstSheetName = workbook.SheetNames[0];
//             const worksheet = workbook.Sheets[firstSheetName];
//             const sheetData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
//             setData(sheetData);
//             // setData(sheetData);
//             setFilteredData(sheetData);
//         };

//         reader.readAsBinaryString(file);
//     };
//     const handleSearchChange = (event) => {
//       const searchValue = event.target.value.toLowerCase();
//       setSearchTerm(searchValue);
//       filterData(searchValue);
//   };
//   const filterData = (searchValue) => {
//     if (searchValue === '') {
//         setFilteredData(data);
//     } else {
//         const filtered = data.filter(row => 
//             row.some(cell => 
//                 cell.toString().toLowerCase().includes(searchValue)
//             )
//         );
//         setFilteredData(filtered);
//     }
// };
//     const handleSaveToDatabase = () => {
//         axios.post('/api/save-employee-data', { data })
//             .then(response => {
//                 console.log('Data saved successfully');
//             })
//             .catch(error => {
//                 console.error('Error saving data:', error);
//             });
//     };

//     return (
//         <div>
//           <div className="mm-ff">
//           <h1 className='employ-head'>Employee</h1>
//           <input value={searchTerm}  onChange={handleSearchChange} className='emp-dash-search' type="text" placeholder='Search' />
//          <button className='employ-search-btn'>
//          <IoSearch  />
//          </button>
//             <input className="input-file-xl" type="file" accept=".xlsx, .xls" onChange={handleFileUpload} />
//             {fileName && <p className="file-name">{fileName}</p>}
//             <button className="upload-excel" onClick={handleSaveToDatabase} disabled={data.length === 0}>Upload</button>
//             </div>

//             <div className="data-preview">
//                 {data.length > 0 && (
//                     <table>
//                         <thead>
//                             <tr>
//                                 {data[0].map((col, index) => <th key={index}>{col}</th>)}
//                             </tr>
//                         </thead>
//                         <tbody>
//                             {data.slice(1).map((row, rowIndex) => (
//                                 <tr key={rowIndex}>
//                                     {row.map((cell, cellIndex) => <td key={cellIndex}>{cell}</td>)}
//                                 </tr>
//                             ))}
//                         </tbody>
//                     </table>
//                 )}
//                 {filteredData.length > 0 && (
//                     <table>
//                         <thead>
//                             <tr>
//                                 {filteredData[0].map((col, index) => <th key={index}>{col}</th>)}
//                             </tr>
//                         </thead>
//                         <tbody>
//                             {filteredData.slice(1).map((row, rowIndex) => (
//                                 <tr key={rowIndex}>
//                                     {row.map((cell, cellIndex) => <td key={cellIndex}>{cell}</td>)}
//                                 </tr>
//                             ))}
//                         </tbody>
//                     </table>
//                 )}
//             </div>
//         </div>
//     );
// };

// export default ExcelUpload;
import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import axios from 'axios';
import './employee.css';

const ExcelUpload = () => {
    const [data, setData] = useState([]); // Original Excel data
    const [filteredData, setFilteredData] = useState([]); // Filtered data based on search
    const [searchTerm, setSearchTerm] = useState(''); // Search term
    const [fileName, setFileName] = useState("");

    const handleFileUpload = (event) => {
        const file = event.target.files[0];
        setFileName(file.name);
        const reader = new FileReader();

        reader.onload = (e) => {
            const binaryStr = e.target.result;
            const workbook = XLSX.read(binaryStr, { type: 'binary' });
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            const sheetData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
            setData(sheetData);
            setFilteredData(sheetData); // Initialize filtered data with original data
        };

        reader.readAsBinaryString(file);
    };

    const handleSaveToDatabase = () => {
        axios.post('/api/save-excel-data', { data })
            .then(response => {
                console.log('Data saved successfully');
            })
            .catch(error => {
                console.error('Error saving data:', error);
            });
    };

    // Handle search input change
    const handleSearchChange = (event) => {
        const searchValue = event.target.value.toLowerCase();
        setSearchTerm(searchValue);
        filterData(searchValue);
    };

    // Filter data based on the search term
    const filterData = (searchValue) => {
        if (searchValue === '') {
            setFilteredData(data);
        } else {
            const filtered = data.filter(row =>
                row.some(cell =>
                    cell.toString().toLowerCase().includes(searchValue)
                )
            );
            setFilteredData(filtered);
        }
    };

    return (
        <div>
          <div className='mm-ff'>
            <h1 className='employ-head'>Employee</h1>
            <input
                type="text"
                placeholder="Search..."
                value={searchTerm}
                onChange={handleSearchChange}
                className="search-input"
            />
            <input className='input-file-xl' type="file" accept=".xlsx, .xls" onChange={handleFileUpload} />
            {fileName && <p className="file-name"></p>}

            

            <button className="upload-excel" onClick={handleSaveToDatabase} disabled={data.length === 0}>Upload</button>
            </div>
            <div className="data-preview">
                {filteredData.length > 0 && (
                    <table>
                        <thead>
                            <tr>
                                {filteredData[0].map((col, index) => <th key={index}>{col}</th>)}
                            </tr>
                        </thead>
                        <tbody>
                            {filteredData.slice(1).map((row, rowIndex) => (
                                <tr key={rowIndex} className={row.some(cell => cell.toString().toLowerCase().includes(searchTerm)) ? 'highlight' : ''}>
                                    {row.map((cell, cellIndex) => <td key={cellIndex}>{cell}</td>)}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
        </div>
    );
};

export default ExcelUpload;
